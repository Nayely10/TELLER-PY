numeros = [ 23, 45, 25,53, 4, 8, 100]
#punto A ejerciio 1
print(numeros[4])
#punto B ejericio 1
numeros.sort()
print(numeros)