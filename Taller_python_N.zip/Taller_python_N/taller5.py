"""crea una lista vacía llamada números, a través de un bucle for o while
pide al usuario que ingrese números enteros, agrega los números a la
lista y luego ordena esta de forma ascendente y descendente. Mostrar
ambas listas (ascendente y descendente)""" 
#punto 5
numeros = [] 
enteros=int(input("Escriba cantidad de numeros enteros a ingresar"))



for i in range(enteros):
    print("Ingrese  un numero entero ",(i+1))
    
 
    numeros.append(input())

numeros.sort(reverse=True)
print(numeros)
numeros.sort()
print(numeros)