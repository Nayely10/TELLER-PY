"""Muestra en consola la longitud de la lista departamentos realizada en
el punto 4."""
#punto 4

Departamentoscol=[]
cant=int(input("ingrese la cantidad de departamentos que desea ingresar. "))

for i in range(cant):
    print("ingrese el nombre del departamento.",(i+1))
    

    Departamentoscol.append(input())

    Departamentoscol.sort(reverse=True)

num=len(Departamentoscol)
print(Departamentoscol)
print(Departamentoscol[num-1])
print(Departamentoscol[num-2])

longitud = len(Departamentoscol)
print("La longitud de la lista de departamentos es :", longitud)