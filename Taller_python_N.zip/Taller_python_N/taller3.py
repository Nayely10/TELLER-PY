"""Crea una lista vacía llamada departamentos Colombia, pida al usuario
la cantidad de departamentos a ingresar, a través de un ciclo for pida
al usuario que ingrese el departamento de Colombia que desee,
agregue esta información a la lista y luego esta sea ordenada en orden
descendente.
a. Se debe imprimir la lista con los valores organizados de forma
descendentes.
b. Debe imprimir además los 2 últimos departamentos ingresados."""




Departamentoscol=[]
cant=int(input('Ingrese la cantidad de departamentos que desea ingresar:'))

for i in range(cant):
    print('Ingrese el nombre del departamento:',(i+1))
    

    Departamentoscol.append(input())

    Departamentoscol.sort(reverse=True)

num=len(Departamentoscol)
print(Departamentoscol)
print(Departamentoscol[num-1])
print(Departamentoscol[num-2])