#punto A
lista_colores ["rojo", "azul", "verde",'amarillo']
#En esta lista hay dos errores falta el simbolo = despues del nombre de la lista, y el color amarillo no
#tiene comillas dobles 
#la manera correcta seria 
lista_colores=["rojo", "azul", "verde", "amarillo"]

#punto B
lista_colores = ["rojo", "azul", "verde", "amarillo"]
print(lista_colores(0))
#el error es que para llamar un elemento de la lista con su indice no se coloca entre parentesis
#se hace asi
print(lista_colores[0])

#punto C
lista_colores = ["rojo", "azul", "verde"]
print(lista_colores[-0])
print(lista_colores[-4]) #el error esta aqui ya que no existe un indice -4

