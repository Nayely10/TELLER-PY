"""6. Realizar un programa que pida un numero positivo, con el ciclo for
muestre en un rango desde 1 hasta el número ingresado, solo los
números pares. """

numeroPositivo = int(input("Ingrese un numero positivo:"))

while numeroPositivo <0:
    numeroPositivo = int(input("Ingresa un numero positivo:"))

arreglo = []

for i in range(numeroPositivo+1):
    if(i%2==0):
        arreglo.append(i)

    print(arreglo)